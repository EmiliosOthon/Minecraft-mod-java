package com.example.hitenchant;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hit Enchant
 * - A chaque coup du joueur sur une entite, l'objet en main recoit un enchantement
 *   aleatoire, meme incompatible avec l'objet (une pelle en terre peut recevoir Tranchant).
 * - Toucher de Soie est totalement exclu.
 * - Les enchantements normalement limites a 1 niveau (Infinite, Tir Multiple, etc.)
 *   restent a 1. Tous les autres peuvent monter jusqu'a 255.
 */
public class HitEnchantMod implements ModInitializer {

    private static final int MAX_LEVEL = 255;
    private static final List<Enchantment> POOL = new ArrayList<>();

    @Override
    public void onInitialize() {
        for (Enchantment ench : Registries.ENCHANTMENT) {
            if (ench == Enchantments.SILK_TOUCH) {
                continue;
            }
            POOL.add(ench);
        }

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            // On applique seulement cote serveur pour que ca persiste reellement sur l'objet.
            if (world.isClient) {
                return ActionResult.PASS;
            }

            ItemStack stack = player.getStackInHand(hand);
            if (stack.isEmpty() || POOL.isEmpty()) {
                return ActionResult.PASS;
            }

            Random random = player.getRandom();
            Enchantment chosen = POOL.get(random.nextInt(POOL.size()));

            int level = (chosen.getMaxLevel() <= 1) ? 1 : 1 + random.nextInt(MAX_LEVEL);

            Map<Enchantment, Integer> current = new HashMap<>(EnchantmentHelper.get(stack));
            current.put(chosen, level);
            EnchantmentHelper.set(current, stack);

            return ActionResult.PASS;
        });
    }
}
