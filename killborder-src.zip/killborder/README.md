# Kill Border

## Compiler
1. Installe Java 17 (JDK).
2. Dans un terminal, place-toi dans ce dossier.
3. Lance : ./gradlew build   (ou gradlew.bat build sous Windows)
4. Le fichier .jar apparait dans build/libs/killborder-1.0.0.jar
5. Copie ce .jar dans le dossier mods de ton instance 1.20.1 Fabric.

Necessite Fabric API installe a cote.
