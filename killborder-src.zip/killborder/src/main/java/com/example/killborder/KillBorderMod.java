package com.example.killborder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;

/**
 * Kill Border
 * - La bordure du monde commence a 20x20 (Overworld).
 * - A chaque mob tue par un joueur, la bordure grandit de 1 bloc.
 *
 * Pour changer les valeurs de depart, modifie START_SIZE et GROWTH_PER_KILL ci-dessous.
 */
public class KillBorderMod implements ModInitializer {

    private static final double START_SIZE = 20.0;
    private static final double GROWTH_PER_KILL = 1.0;

    @Override
    public void onInitialize() {

        // Fixe la taille de depart la premiere fois que l'Overworld se charge.
        // On ne touche a rien si la bordure a deja ete reduite par ce mod ou par un joueur
        // (on considere qu'une bordure encore a sa taille vanilla par defaut, tres grande,
        // n'a jamais ete configuree).
        ServerWorldEvents.LOAD.register((server, world) -> {
            if (world.getRegistryKey() == World.OVERWORLD) {
                WorldBorder border = world.getWorldBorder();
                if (border.getSize() > 1_000_000) {
                    border.setSize(START_SIZE);
                }
            }
        });

        // A chaque mort d'une entite vivante tuee par un joueur, on agrandit la bordure.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            Entity attacker = resolveAttacker(damageSource);
            if (attacker instanceof PlayerEntity) {
                WorldBorder border = entity.getWorld().getWorldBorder();
                border.setSize(border.getSize() + GROWTH_PER_KILL);
            }
        });
    }

    private Entity resolveAttacker(DamageSource damageSource) {
        // getAttacker() couvre les coups directs ET les degats attribues au joueur
        // (par exemple une fleche tiree par le joueur).
        return damageSource.getAttacker();
    }
}
